#ifndef __SORTE_H
#define __SORTE_H

#include <stdio.h>
/**D�finition du type S, un entier, pour pouvoir changer le type des �l�ments de la liste � la vol�e */
typedef int S;

#endif
