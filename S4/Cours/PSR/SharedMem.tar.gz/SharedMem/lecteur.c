// code source du processus lecteur
#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <unistd.h>

#include "segmem.h"

int main()
{
	int mem_ID_B; // identificateur du segment 
	void* ptr_mem_partagee_B; // adresse d'attachement du segment de mémoire partagée 
	
	structure_partagee *data;
	
 	printf("Je suis le processus %d\n", getpid());	

	if ((mem_ID_B = shmget(CLEF, sizeof(structure_partagee), 0444)) < 0) // droits de lecture uniquement 
	{
		perror("shmget"); // et je m'assure que l'espace mémoire a été correctement créé
		exit(1);
	}
	printf("Id : %d\n", mem_ID_B);
	// attachement
	if ((ptr_mem_partagee_B = shmat(mem_ID_B, NULL, 0)) == (void*) -1) {
		perror("shmat"); // et je m'assure que le segment de mémoire a été correctement attaché à mon processus
		exit(2);
	}
	
	printf("adresse d'attachement : %p\n", ptr_mem_partagee_B);

	data = (structure_partagee*)ptr_mem_partagee_B;
	// lecture
	do
	{
		printf("data->a = %d\n",data->a);
		printf("data->b = %f\n",data->b);

		sleep(2);
	}
	while( data->a < 99 );
	
	// destruction du segment
	shmdt(ptr_mem_partagee_B);
	
	return 0;
} 
