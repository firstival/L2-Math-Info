// code source du processus ecrivain
#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <unistd.h>

#include "segmem.h"

int main()
{
	int i;	// compteur
	
	int mem_ID; // identificateur du segment de mémoire partagée associé à CLEF
	void* ptr_mem_partagee; // pointeur sur l'adresse d'attachement du segment de mémoire partagée
	struct shmid_ds shmds;

	structure_partagee *data;
	
 	printf("Je suis le processus %d\n", getpid());	

	// creation du segment 
	if ((mem_ID = shmget(CLEF, sizeof(structure_partagee), 0666 | IPC_CREAT)) < 0)  {
		perror("shmget"); // je m'assure que l'espace mémoire a été correctement créé
		exit(1);
	}
	printf("Id : %d\n", mem_ID);
	// attachement du segment
	if ((ptr_mem_partagee = shmat(mem_ID, NULL, 0)) == (void*) -1) {
		perror("shmat"); 
		exit(2);
	}

	printf("adresse d'attachement : %p\n", ptr_mem_partagee);
	
	// initialisation des donnees
	data = (structure_partagee *)ptr_mem_partagee;
	data->a = 8;
	data->b = 3.14;
	
	// je vais modifier en permanence le champ a de ma structure et le mettre à jour, le processus B lira la structure Data.
	for( i=0 ; i<100 ; i++ )
	{
		sleep(1);
		data->a = i;
	}
	
	// Détachement du segment 
	shmdt(ptr_mem_partagee);
	
	// sera detruit lorsque tous les proc se seront detaches
	shmctl( mem_ID, IPC_RMID, &shmds );

	return( 0 );
}
