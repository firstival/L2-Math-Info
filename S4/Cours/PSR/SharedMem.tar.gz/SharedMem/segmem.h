
// clef identifiant le segment de memoire partagée
#define CLEF 0x64738

// structure de données
typedef struct {
        int a;
        double b;
} structure_partagee;

