/* Emboitement de signaux */

#include <stdio.h>
#include <signal.h>
#include <unistd.h>

/* 
 * Rappel struct action :
 *   struct sigaction {
	void  (*sa_handler)(int) ; // SIG_DFL, SIG_IGN, ou un handler perso
	sigset_t  sa_mask ;	// masque des signaux à bloquer
	int  sa_flags ;
      }
  */

int stack=0;

void handler(int signum) {
	int i, ntab;

	stack++;
	printf("Signal %d reçu\n", signum); 
	printf("Traitement signal niveau %d \n", stack);
	for(i=0; i< 5; i++) {
		for(ntab = 0; ntab < stack; ntab++) { printf("\t"); }
		printf("Traitement signal %d en cours\n", signum);
		sleep(1);
	}
	printf("Fin du traitement niveau %d\n", stack);
	stack--;
} 

main () {
	struct sigaction action;

	printf("Je suis le processus de pid : %d\n", getpid());

	action.sa_handler = handler;
	action.sa_flags = SA_NODEFER;
	sigaction(SIGINT, &action, NULL);
	sigaction(SIGFPE, &action, NULL);
//	sigaction(SIGQUIT, &action, NULL);

	while (1) {
		printf("Traitement normal\n");
		sleep(1);
	}
} 
