#include <stdio.h>
#include <signal.h>
#include <unistd.h>

/* 
 * Rappel struct action :
 *   struct sigaction {
	void  (*sa_handler)(int) ; // SIG_DFL, SIG_IGN, ou un handler perso
	sigset_t  sa_mask ;	// masque des signaux à bloquer
	int  sa_flags ;
      }
  */

void handler(int signum) {
	printf("Signal %d reçu (proc : %d)\n", signum, getpid()); 
} 

main () {
	struct sigaction action;
	pid_t fils, pere;

	action.sa_handler = handler;
	sigaction(SIGINT, &action, NULL);

	fils = fork();

	while (1) {
		printf("Je suis le %s (pid : %d) et je continue \n", (fils==0?"fils":"pere"), getpid());
		if (fils) { sleep(5); } else { sleep(3); }
	}
} 
