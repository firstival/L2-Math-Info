#include <stdio.h>
#include <signal.h>
#include <unistd.h>

/* 
 * Rappel struct action :
 *   struct sigaction {
	void  (*sa_handler)(int) ; // SIG_DFL, SIG_IGN, ou un handler perso
	sigset_t  sa_mask ;	// masque des signaux à bloquer
	int  sa_flags ;
      }
  */

void handler(int signum) {
	printf("Signal %d reçu\n", signum); 
} 

main () {
	struct sigaction action, action2;

	printf("Mon pid est le %d\n", getpid());

	action.sa_handler = handler;
	sigaction(SIGINT, &action, NULL);

	sigaction(SIGSEGV, &action, NULL);

	int *p=NULL;

	*p = 3;

	while (1) {
		printf("Je continue\n");
		sleep(1);
	}
} 
