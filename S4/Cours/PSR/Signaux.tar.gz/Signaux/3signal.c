/* Blocage d'un signal */

#include <stdio.h>
#include <signal.h>
#include <unistd.h>

/* 
 * Rappel struct action :
 *   struct sigaction {
	void  (*sa_handler)(int) ; // SIG_DFL, SIG_IGN, ou un handler perso
	sigset_t  sa_mask ;	// masque des signaux à bloquer
	int  sa_flags ;
      }
  */

void handler(int signum) {
	printf("Signal %d reçu\n", signum); 
	return;
} 

main () {
	struct sigaction action;
	sigset_t new_mask, old_mask, pending;
	
	int nb_sec=0, i;

	printf("Mon pid est le %d\n", getpid());

	action.sa_handler = handler;
	sigaction(SIGINT, &action, NULL);	// crtl C
//	sigaction(SIGQUIT, &action, NULL);	// ctrl \

	sigemptyset(&new_mask);
	sigaddset(&new_mask, SIGINT);		
	sigaddset(&new_mask, SIGSEGV);
	sigprocmask(SIG_BLOCK, &new_mask, &old_mask); // on ignore crtl C + le signal segmentation fault 

	printf(" %d\n", NSIG);
	while (1) {
		printf("Je continue\n");
		sleep(9);
		nb_sec++;
		if (nb_sec == 5) {
			printf("Bon d'accord ... je me démasque\n");
			sigpending(&pending);
			for(i=1; i < NSIG-1; i++) {
				if (sigismember(&pending, i)) {
					printf("Signal %d pendant\n", i);
				}
			}
			sigprocmask(SIG_UNBLOCK, &new_mask, &old_mask);
		}
	}
} 
