#include <stdio.h>

main () {
	printf("Mon pid est le %d\n", getpid());
	while (1) {
		sleep(1);
	}
} 
