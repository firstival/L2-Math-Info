/** \file
 * Source : Main
 **/

#include <stdio.h>
#include <stdlib.h>

#include "shell.h"

int main(int argc, char *argv[])
{
	shell();
	return 0;
}
